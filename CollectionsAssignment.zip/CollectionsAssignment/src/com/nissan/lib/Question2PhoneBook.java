package com.nissan.lib;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * Develop an application to implement a phone book. There should be provision to add,
delete and search phone numbers. The entries should in sorted order.
 */

public class Question2PhoneBook {

	public static HashMap<String, Long> phoneBook = new HashMap<String, Long>();
	public static Scanner scanner = new Scanner(System.in);
	public static Scanner scanner1 = new Scanner(System.in);

	public static void mainMenu() {
		char choice = 'n';
		int menuChoice;
		try {
			do {
				System.out.println("------PhoneBook------");
				System.out.print("1. Add new entry\n2. Delete entry\n3. Search for a number\nPlease choose: ");
				menuChoice = Integer.parseInt(scanner.nextLine());

				switch (menuChoice) {

				case 1:
					addNewEntry();
					break;
				case 2:
					deleteEntry();
					break;
				case 3:
					search();
					break;
				default:
					System.out.println("Invalid selection");
				}

				System.out.print("Do you want to continue?(Y/N): ");
				choice = scanner1.next().charAt(0);
			} while ((choice == 'y') || (choice == 'Y'));

			System.out.println("Thank You! Exiting...");
		} catch (Exception e) {
			System.out.println("Invalid entry");
		}
	}

	private static void addNewEntry() {

		String name;
		Long number;
		int flag;
		try {
			System.out.println("-------New entry-------");

			// getting name from user
			do {
				flag = 0;
				System.out.print("Please enter your name: ");
				name = getValidName(scanner.nextLine());

				// check if it already exists
				if (checkNameExists(name)) {
					System.out.println("Name already exists. Try again.");
					flag = 1;
				}
			} while (flag == 1);

			// getting phone number from user
			do {
				flag = 0;
				System.out.print("Please enter your phone number: ");
				number = getValidNumber(scanner.nextLine());

				// check if number already exists
				if (checkNumberExists(number)) {
					System.out.println("Number already exists. Try again.");
					flag = 1;
				}
			} while (flag == 1);

			// inserting into hashMap
			phoneBook.put(name, number);
		} catch (Exception e) {
			System.out.println("Invalid entry");
		}
	}

	private static void deleteEntry() {

		int flag;
		String name;
		try {

			// getting name from user
			do {
				flag = 0;
				System.out.print("Please the contact name to be deleted: ");
				name = getValidName(scanner.nextLine());

				// check if it exists
				if (!checkNameExists(name)) {
					System.out.println("No such contact found. Try again.");
					flag = 1;
				}
			} while (flag == 1);

			phoneBook.remove(name);
			System.out.println("Contact deleted.");
		} catch (Exception e) {
			System.out.println("Invalid entry");
		}
	}

	private static void search() {
		int flag;
		String name;
		try {

			// getting name from user
			do {
				flag = 0;
				System.out.print("Please the contact name to be searched: ");
				name = getValidName(scanner.nextLine());

				// check if it exists
				if (!checkNameExists(name)) {
					System.out.println("No such contact found. Try again.");
					flag = 1;
				}
			} while (flag == 1);
			
			System.out.println("1 Entry found");
			System.out.println("Name: " + name + "		Contact Number: " + phoneBook.get(name));
		} catch (Exception e) {
			System.out.println("Invalid entry");
		}
	}

	private static String getValidName(String name) {
		try {

			// creating pattern using regular expression
			Pattern pattern = Pattern.compile("[^A-Za-z ]");

			do {

				// Match
				Matcher matcher = pattern.matcher(name);
				boolean finder = matcher.find();

				if (finder) {
					System.out.print("Name must contain only alphabets. Please re-enter name: ");
					name = scanner.nextLine();
				} else if (name.length() < 3) {
					System.out.print("Name should contain minimum 3 characters. Please re-enter name: ");
					name = scanner.nextLine();
				} else {
					break;
				}

			} while (true);

		} catch (Exception e) {
			System.out.println("Invalid name");
		}

		return name;
	}

	private static boolean checkNameExists(String name) {

		if (phoneBook.size() == 0) {
			return false;
		} else {
			for (Map.Entry m : phoneBook.entrySet()) {
				if (m.getKey().equals(name)) {
					return true;
				}
			}
		}
		return false;
	}

	private static long getValidNumber(String number) {

		try {
			Pattern numberPattern = Pattern.compile("[^0-9]");

			do {

				Matcher numberMatcher = numberPattern.matcher(number);
				boolean finder = numberMatcher.find();

				if (finder) {
					System.out.print("Phone number can contain only numbers. Please re-enter: ");
					number = scanner.nextLine();
				} else if (number.length() <= 0) {
					System.out.print("Field cannot be blank. Please re-enter: ");
					number = scanner.nextLine();
				} else if (number.length() != 10) {
					System.out.print("Phone number should have 10 digits. Please re-enter: ");
					number = scanner.nextLine();
				} else {
					break;
				}

			} while (true);
		} catch (Exception e) {
			System.out.println("Invalid entry");
		}
		return Long.parseLong(number);
	}

	private static boolean checkNumberExists(Long number) {

		if (phoneBook.size() == 0) {
			return false;
		} else {
			for (Map.Entry m : phoneBook.entrySet()) {
				if (m.getValue().equals(number)) {
					return true;
				}
			}
		}
		return false;
	}

}
