package com.nissan.lib;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

//1. Create an array with duplicate values. Using collections to print all duplicate values.

public class Question1 {

	public static void getUserInput() {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		//declaring array
		int[] arr = new int[5];
		try {
			
			//getting 5 entries from user
			System.out.println("Please enter 5 numbers with duplicate values: ");
			for(int i = 0; i<5; i++) {
				System.out.print("Value " + (i+1) + ": ");
				arr[i] = Integer.parseInt(br.readLine());
			}
			
			//converting to a collection
			convertToCollection(arr);
		}catch(Exception e) {
			System.out.println("Invalid entry");
		}
	}

	private static void convertToCollection(int[] arr) {
		
		try {
			List<Integer> myList = new ArrayList<Integer>();
			//adding elements from array to List
			for(int i : arr)
				myList.add(i);
			
			//displaying all elements in list
			for(Integer element : myList)
				System.out.println(element);
		}catch(Exception e) {
			System.out.println("Invalid entry");
		}
	}
}
