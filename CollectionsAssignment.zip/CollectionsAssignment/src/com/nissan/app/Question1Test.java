package com.nissan.app;

import com.nissan.lib.Question1;

//1. Create an array with duplicate values. Using collections to print all duplicate values.

public class Question1Test {

	public static void main(String[] args) {
		
		Question1.getUserInput();
	}

}
