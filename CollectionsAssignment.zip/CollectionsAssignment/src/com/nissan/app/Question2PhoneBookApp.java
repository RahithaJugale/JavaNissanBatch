package com.nissan.app;

import com.nissan.lib.Question2PhoneBook;

/*
 * Develop an application to implement a phone book. There should be provision to add,
delete and search phone numbers. The entries should in sorted order.
 */

public class Question2PhoneBookApp {

	public static void main(String[] args) {
		
		Question2PhoneBook.mainMenu();
		
	}

}
