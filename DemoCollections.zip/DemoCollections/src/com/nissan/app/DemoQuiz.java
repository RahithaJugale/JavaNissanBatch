package com.nissan.app;

import com.nissan.col.DemoQuizCollection;

public class DemoQuiz {

	public static void main(String[] args) {
		DemoQuizCollection quiz = new DemoQuizCollection();
		quiz.mainMenu();
	}

}
